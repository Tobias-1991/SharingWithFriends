﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project4
{
    class GameBoard
    {
        int gameboardSpace = 0;
        bool isX;
        bool isWinner;

        public GameBoard(int width, int height)
        {
            int[,] gameBoard = new int[width, height];

        }
        // variables needed 
        /*
         int gameBoardSpace
         bool isX;
        
         
         
         */


    }

}
